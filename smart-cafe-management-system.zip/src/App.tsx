import React, { useState, useEffect, useMemo } from 'react';
import {
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  handleFirestoreError,
  OperationType,
  User
} from './firebase';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Users,
  BarChart3,
  LogOut,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  Coffee,
  ChevronRight,
  Search,
  Filter,
  MoreVertical,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';

// --- Types ---

interface OrderItem {
  menuItemId: string;
  name: string;
  quantity: number;
  price: number;
}

interface Order {
  id: string;
  customerId: string;
  items: OrderItem[];
  total: number;
  status: 'pending' | 'preparing' | 'ready' | 'completed' | 'cancelled';
  createdAt: any;
  updatedAt?: any;
}

interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  minThreshold: number;
}

interface StaffMember {
  uid: string;
  name: string;
  role: 'admin' | 'manager' | 'barista' | 'chef' | 'server' | 'client';
  email: string;
  status: 'active' | 'inactive' | 'on-break';
}

// --- Components ---

const Button = ({ children, onClick, variant = 'primary', className = '', disabled = false, icon: Icon }: any) => {
  const variants: any = {
    primary: 'bg-orange-600 text-white hover:bg-orange-700',
    secondary: 'bg-zinc-800 text-zinc-100 hover:bg-zinc-700',
    outline: 'border border-zinc-700 text-zinc-300 hover:bg-zinc-800',
    danger: 'bg-red-600 text-white hover:bg-red-700',
    ghost: 'text-zinc-400 hover:text-white hover:bg-zinc-800'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${className}`}
    >
      {Icon && <Icon size={18} />}
      {children}
    </button>
  );
};

const Card = ({ children, title, subtitle, icon: Icon, className = '' }: any) => (
  <div className={`bg-zinc-900 border border-zinc-800 rounded-xl p-6 ${className}`}>
    {(title || Icon) && (
      <div className="flex items-center justify-between mb-6">
        <div>
          {title && <h3 className="text-lg font-semibold text-white">{title}</h3>}
          {subtitle && <p className="text-sm text-zinc-500">{subtitle}</p>}
        </div>
        {Icon && <div className="p-2 bg-orange-600/10 rounded-lg text-orange-500"><Icon size={20} /></div>}
      </div>
    )}
    {children}
  </div>
);

const Badge = ({ children, variant = 'default' }: any) => {
  const variants: any = {
    default: 'bg-zinc-800 text-zinc-300',
    success: 'bg-emerald-500/10 text-emerald-500',
    warning: 'bg-amber-500/10 text-amber-500',
    danger: 'bg-red-500/10 text-red-500',
    info: 'bg-blue-500/10 text-blue-500'
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${variants[variant]}`}>
      {children}
    </span>
  );
};

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/20' : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </button>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [orders, setOrders] = useState<Order[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [showNewOrder, setShowNewOrder] = useState(false);

  // --- Auth ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      if (u) {
        setUser(u);
        // Ensure user document exists
        const userRef = doc(db, 'users', u.uid);
        let userSnap = await getDoc(userRef);
        const isAdminEmail = ['udayaprinter.gamini@gmail.com', 'udayatube2020@gmail.com'].includes(u.email || '');
        if (!userSnap.exists()) {
          const newUser = {
            uid: u.uid,
            name: u.displayName || 'Anonymous',
            email: u.email,
            role: isAdminEmail ? 'admin' : 'client',
            status: 'active'
          };
          await setDoc(userRef, newUser);
          setUserRole(isAdminEmail ? 'admin' : 'client');
        } else {
          const data = userSnap.data();
          if (isAdminEmail && data?.role !== 'admin') {
            await setDoc(userRef, { ...data, role: 'admin' }, { merge: true });
            setUserRole('admin');
          } else {
            setUserRole(data?.role || 'client');
          }
        }
      } else {
        setUser(null);
        setUserRole(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // --- Data Listeners ---
  useEffect(() => {
    if (!user || !userRole) return;

    // Only staff/admin can see the full dashboard data
    const isStaff = ['admin', 'manager', 'barista', 'chef', 'server'].includes(userRole);
    // Fallback for hardcoded admins (even if role in DB is still 'client')
    const isAdminEmail = user.email === 'udayaprinter.gamini@gmail.com' || user.email === 'udayatube2020@gmail.com';
    
    if (!isStaff && !isAdminEmail) {
      // If client, maybe only listen to their own orders
      const qMyOrders = query(collection(db, 'orders'), where('customerId', '==', user.uid), orderBy('createdAt', 'desc'), limit(20));
      const unsubMyOrders = onSnapshot(qMyOrders, (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setOrders(data);
      }, (err) => console.error('My Orders Error:', err));
      return () => unsubMyOrders();
    }

    const qOrders = query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(50));
    const unsubOrders = onSnapshot(qOrders, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setOrders(data);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'orders'));

    const qInventory = collection(db, 'inventory');
    const unsubInventory = onSnapshot(qInventory, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem));
      setInventory(data);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'inventory'));

    const qStaff = collection(db, 'users');
    const unsubStaff = onSnapshot(qStaff, (snapshot) => {
      const data = snapshot.docs
        .map(doc => ({ uid: doc.id, ...doc.data() } as StaffMember))
        .filter(s => s.role !== 'client');
      setStaff(data);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));

    return () => {
      unsubOrders();
      unsubInventory();
      unsubStaff();
    };
  }, [user, userRole]);

  // --- Handlers ---
  const seedData = async () => {
    if (!user) return;
    const isAdminEmail = user.email === 'udayaprinter.gamini@gmail.com' || user.email === 'udayatube2020@gmail.com';
    if (!isAdminEmail) return;

    try {
      // Seed Inventory
      const invSnap = await getDocs(collection(db, 'inventory'));
      if (invSnap.empty) {
        const items = [
          { name: 'Coffee Beans', quantity: 50, unit: 'kg', minThreshold: 10 },
          { name: 'Milk', quantity: 100, unit: 'L', minThreshold: 20 },
          { name: 'Sugar', quantity: 30, unit: 'kg', minThreshold: 5 },
          { name: 'Croissants', quantity: 40, unit: 'pcs', minThreshold: 10 },
          { name: 'Espresso Cups', quantity: 200, unit: 'pcs', minThreshold: 50 }
        ];
        for (const item of items) {
          await setDoc(doc(collection(db, 'inventory')), item);
        }
      }

      // Seed Staff (including current user as admin)
      const staffSnap = await getDocs(query(collection(db, 'users'), where('role', '!=', 'client')));
      if (staffSnap.empty) {
        await updateDoc(doc(db, 'users', user.uid), { role: 'admin', status: 'active' });
        const otherStaff = [
          { name: 'Alice Smith', role: 'barista', email: 'alice@cafe.com', status: 'active', uid: 'staff-1' },
          { name: 'Bob Jones', role: 'chef', email: 'bob@cafe.com', status: 'on-break', uid: 'staff-2' }
        ];
        for (const s of otherStaff) {
          await setDoc(doc(db, 'users', s.uid), s);
        }
      }
    } catch (error) {
      console.error('Seeding error:', error);
    }
  };

  useEffect(() => {
    if (user) seedData();
  }, [user]);

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status, updatedAt: new Date() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const createSampleOrder = async () => {
    if (!user) return;
    try {
      const newOrder: Omit<Order, 'id'> = {
        customerId: user.uid,
        items: [
          { menuItemId: 'coffee-1', name: 'Espresso', quantity: 1, price: 3.50 },
          { menuItemId: 'pastry-1', name: 'Croissant', quantity: 1, price: 4.25 }
        ],
        total: 7.75,
        status: 'pending',
        createdAt: new Date()
      };
      await setDoc(doc(collection(db, 'orders')), newOrder);
      setShowNewOrder(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
    }
  };

  // --- Analytics Data ---
  const salesData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return format(d, 'MMM dd');
    }).reverse();

    return last7Days.map(day => {
      const dayOrders = orders.filter(o => o.createdAt && format(o.createdAt.toDate ? o.createdAt.toDate() : new Date(o.createdAt), 'MMM dd') === day);
      return {
        name: day,
        sales: dayOrders.reduce((sum, o) => sum + o.total, 0),
        orders: dayOrders.length
      };
    });
  }, [orders]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-orange-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-zinc-800/30 rounded-full blur-[120px]" />
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 text-center max-w-md"
        >
          <div className="w-20 h-20 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-orange-600/40">
            <Coffee size={40} className="text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4 tracking-tight">Smart Cafe</h1>
          <p className="text-zinc-400 mb-10 leading-relaxed">
            The next generation of cafe management. Precision, automation, and intelligence in every cup.
          </p>
          <Button onClick={handleLogin} className="w-full py-4 text-lg" icon={LayoutDashboard}>
            Sign in with Google
          </Button>
        </motion.div>
      </div>
    );
  }

  const isStaff = ['admin', 'manager', 'barista', 'chef', 'server'].includes(userRole || '');
  const isAdminEmail = user.email === 'udayaprinter.gamini@gmail.com' || user.email === 'udayatube2020@gmail.com';
  const hasStaffAccess = isStaff || isAdminEmail;

  if (!hasStaffAccess) {
    return (
      <div className="min-h-screen bg-black text-zinc-100 flex flex-col items-center justify-center p-6">
        <div className="w-20 h-20 bg-orange-600/10 rounded-2xl flex items-center justify-center mb-8">
          <Coffee size={40} className="text-orange-500" />
        </div>
        <h1 className="text-3xl font-bold mb-4">Welcome to Smart Cafe</h1>
        <p className="text-zinc-400 text-center max-w-md mb-8">
          You are currently signed in as a customer. Your order history will appear here once you place an order.
        </p>
        
        <div className="w-full max-w-2xl">
          <Card title="My Orders" subtitle="Track your recent coffee orders">
            {orders.length === 0 ? (
              <div className="py-12 text-center text-zinc-500">
                No orders found.
              </div>
            ) : (
              <div className="flex flex-col gap-4 mt-6">
                {orders.map(order => (
                  <div key={order.id} className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-xl border border-zinc-800">
                    <div>
                      <p className="font-medium text-white">Order #{order.id.slice(-6)}</p>
                      <p className="text-sm text-zinc-500">{order.items.map(i => i.name).join(', ')}</p>
                    </div>
                    <Badge variant={order.status === 'completed' ? 'success' : 'warning'}>{order.status}</Badge>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <Button variant="ghost" onClick={handleLogout} className="mt-8" icon={LogOut}>
          Logout
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex">
      {/* Sidebar */}
      <aside className="w-72 border-r border-zinc-800 p-6 flex flex-col gap-8 sticky top-0 h-screen">
        <div className="flex items-center gap-3 px-2">
          <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center">
            <Coffee size={24} className="text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">Smart Cafe</span>
        </div>

        <nav className="flex-1 flex flex-col gap-2">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={ShoppingCart} label="Orders" active={activeTab === 'orders'} onClick={() => setActiveTab('orders')} />
          <SidebarItem icon={Package} label="Inventory" active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} />
          <SidebarItem icon={Users} label="Staff" active={activeTab === 'staff'} onClick={() => setActiveTab('staff')} />
          <SidebarItem icon={BarChart3} label="Analytics" active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} />
        </nav>

        <div className="pt-6 border-t border-zinc-800">
          <div className="flex items-center gap-3 mb-6 px-2">
            <img src={user.photoURL || ''} alt="" className="w-10 h-10 rounded-full border border-zinc-700" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user.displayName}</p>
              <p className="text-xs text-zinc-500 truncate">{user.email}</p>
            </div>
          </div>
          <Button variant="ghost" onClick={handleLogout} className="w-full justify-start" icon={LogOut}>
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-10 overflow-y-auto">
        <header className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-bold text-white tracking-tight capitalize">{activeTab}</h2>
            <p className="text-zinc-500">Welcome back, {user.displayName?.split(' ')[0]}</p>
          </div>
          <div className="flex gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
              <input
                type="text"
                placeholder="Search anything..."
                className="bg-zinc-900 border border-zinc-800 rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-orange-600 transition-colors w-64"
              />
            </div>
            <Button onClick={() => setShowNewOrder(true)} icon={Plus}>New Order</Button>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-12 gap-6">
            <Card className="col-span-3" title="Total Revenue" subtitle="Last 7 days" icon={BarChart3}>
              <p className="text-3xl font-bold text-white mt-2">${salesData.reduce((s, d) => s + d.sales, 0).toFixed(2)}</p>
              <div className="mt-4 flex items-center gap-2 text-emerald-500 text-sm font-medium">
                <ChevronRight size={14} className="-rotate-90" />
                <span>+12.5% from last week</span>
              </div>
            </Card>
            <Card className="col-span-3" title="Total Orders" subtitle="Last 7 days" icon={ShoppingCart}>
              <p className="text-3xl font-bold text-white mt-2">{salesData.reduce((s, d) => s + d.orders, 0)}</p>
              <div className="mt-4 flex items-center gap-2 text-emerald-500 text-sm font-medium">
                <ChevronRight size={14} className="-rotate-90" />
                <span>+8.2% from last week</span>
              </div>
            </Card>
            <Card className="col-span-3" title="Active Staff" subtitle="Currently on shift" icon={Users}>
              <p className="text-3xl font-bold text-white mt-2">{staff.filter(s => s.status === 'active').length}</p>
              <div className="mt-4 flex items-center gap-2 text-zinc-500 text-sm font-medium">
                <span>{staff.length} total staff members</span>
              </div>
            </Card>
            <Card className="col-span-3" title="Low Stock" subtitle="Items needing attention" icon={Package}>
              <p className="text-3xl font-bold text-white mt-2">{inventory.filter(i => i.quantity <= i.minThreshold).length}</p>
              <div className="mt-4 flex items-center gap-2 text-amber-500 text-sm font-medium">
                <AlertCircle size={14} />
                <span>Check inventory soon</span>
              </div>
            </Card>

            <Card className="col-span-8" title="Revenue Overview" subtitle="Daily sales performance">
              <div className="h-[300px] mt-6">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={salesData}>
                    <defs>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ea580c" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#ea580c" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                    <XAxis dataKey="name" stroke="#71717a" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="#71717a" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}`} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                      itemStyle={{ color: '#fff' }}
                    />
                    <Area type="monotone" dataKey="sales" stroke="#ea580c" strokeWidth={2} fillOpacity={1} fill="url(#colorSales)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="col-span-4" title="Recent Orders" subtitle="Latest transactions">
              <div className="flex flex-col gap-4 mt-6">
                {orders.slice(0, 5).map(order => (
                  <div key={order.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-zinc-800/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${order.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      <div>
                        <p className="text-sm font-medium text-white">Order #{order.id.slice(-4)}</p>
                        <p className="text-xs text-zinc-500">{order.items.length} items • ${order.total.toFixed(2)}</p>
                      </div>
                    </div>
                    <Badge variant={order.status === 'completed' ? 'success' : 'warning'}>{order.status}</Badge>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'orders' && (
          <Card title="Order Management" subtitle="Track and update customer orders">
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 text-xs uppercase tracking-wider">
                    <th className="px-4 py-4 font-medium">Order ID</th>
                    <th className="px-4 py-4 font-medium">Customer</th>
                    <th className="px-4 py-4 font-medium">Items</th>
                    <th className="px-4 py-4 font-medium">Total</th>
                    <th className="px-4 py-4 font-medium">Status</th>
                    <th className="px-4 py-4 font-medium">Time</th>
                    <th className="px-4 py-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {orders.map(order => (
                    <tr key={order.id} className="hover:bg-zinc-800/30 transition-colors group">
                      <td className="px-4 py-4 text-sm font-medium text-white">#{order.id.slice(-6)}</td>
                      <td className="px-4 py-4 text-sm text-zinc-400">{order.customerId.slice(0, 8)}...</td>
                      <td className="px-4 py-4 text-sm text-zinc-400">
                        {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                      </td>
                      <td className="px-4 py-4 text-sm font-semibold text-white">${order.total.toFixed(2)}</td>
                      <td className="px-4 py-4">
                        <Badge variant={order.status === 'completed' ? 'success' : order.status === 'cancelled' ? 'danger' : 'warning'}>
                          {order.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-sm text-zinc-500">
                        {order.createdAt?.toDate ? format(order.createdAt.toDate(), 'HH:mm') : 'Now'}
                      </td>
                      <td className="px-4 py-4 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          {order.status === 'pending' && (
                            <Button variant="ghost" className="p-1" onClick={() => updateOrderStatus(order.id, 'preparing')}>
                              <Clock size={16} className="text-amber-500" />
                            </Button>
                          )}
                          {order.status === 'preparing' && (
                            <Button variant="ghost" className="p-1" onClick={() => updateOrderStatus(order.id, 'ready')}>
                              <CheckCircle2 size={16} className="text-blue-500" />
                            </Button>
                          )}
                          {order.status === 'ready' && (
                            <Button variant="ghost" className="p-1" onClick={() => updateOrderStatus(order.id, 'completed')}>
                              <CheckCircle2 size={16} className="text-emerald-500" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {activeTab === 'inventory' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {inventory.map(item => (
              <Card key={item.id} title={item.name} subtitle={`${item.quantity} ${item.unit} available`} icon={Package}>
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-2">
                    <span className="text-zinc-500">Stock Level</span>
                    <span className={item.quantity <= item.minThreshold ? 'text-red-500' : 'text-emerald-500'}>
                      {Math.round((item.quantity / (item.minThreshold * 3)) * 100)}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${item.quantity <= item.minThreshold ? 'bg-red-500' : 'bg-emerald-500'}`}
                      style={{ width: `${Math.min(100, (item.quantity / (item.minThreshold * 3)) * 100)}%` }}
                    />
                  </div>
                </div>
                <div className="mt-6 flex gap-2">
                  <Button variant="outline" className="flex-1 text-xs">Restock</Button>
                  <Button variant="ghost" className="p-2">
                    <MoreVertical size={16} />
                  </Button>
                </div>
              </Card>
            ))}
            <button
              className="border-2 border-dashed border-zinc-800 rounded-xl p-6 flex flex-col items-center justify-center gap-3 text-zinc-500 hover:border-orange-600 hover:text-orange-600 transition-all duration-200"
              onClick={() => {}}
            >
              <Plus size={32} />
              <span className="font-medium">Add Item</span>
            </button>
          </div>
        )}

        {activeTab === 'staff' && (
          <Card title="Staff Directory" subtitle="Manage your team and their roles">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              {staff.map(member => (
                <div key={member.uid} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl border border-zinc-800">
                  <div className="w-12 h-12 bg-zinc-700 rounded-full flex items-center justify-center text-zinc-400">
                    <Users size={24} />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium">{member.name}</h4>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">{member.role}</p>
                  </div>
                  <Badge variant={member.status === 'active' ? 'success' : 'default'}>{member.status}</Badge>
                </div>
              ))}
            </div>
          </Card>
        )}
      </main>

      {/* New Order Modal */}
      <AnimatePresence>
        {showNewOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowNewOrder(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-white">Create New Order</h3>
                <button onClick={() => setShowNewOrder(false)} className="text-zinc-500 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-700">
                  <div className="flex justify-between mb-2">
                    <span className="text-zinc-300">Espresso</span>
                    <span className="text-white font-medium">$3.50</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-300">Croissant</span>
                    <span className="text-white font-medium">$4.25</span>
                  </div>
                  <div className="mt-4 pt-4 border-t border-zinc-700 flex justify-between">
                    <span className="text-lg font-bold text-white">Total</span>
                    <span className="text-lg font-bold text-orange-500">$7.75</span>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button variant="outline" className="flex-1" onClick={() => setShowNewOrder(false)}>Cancel</Button>
                  <Button className="flex-1" onClick={createSampleOrder}>Confirm Order</Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
